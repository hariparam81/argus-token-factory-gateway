# Review brief: the token factory post

You are reviewing `post-for-claude-review.html`, a Medium post draft titled "A Framework for Running a Shared Inference Service." Review it against the ground-truth files in this bundle, not against taste. Report findings as a list the author can accept or reject item by item. Do not rewrite the post wholesale.

## Files and what each is for

- `post-for-claude-review.html` — the draft under review.
- `RUN-REPORT.md` — ground truth for every number and event in the run. If the post and the run report disagree, the run report wins.
- `sources/framework-report.md` — ground truth for the design: identity paths, the resolved principal, isolation mechanics, the audit record.
- `sources/evidence-bank.md` and `sources/evidence-refresh-2026.md` — ground truth for citations. The refresh supersedes the bank where they conflict; use the refresh's 2026 figures.
- `sources/cost-per-outcome.md` — the published results behind the cost tenet and reference [5].
- `writing-style-instructions.md` — the author's style rules. The bar is zero hits.
- `plan-and-decisions.md` — the structure plan and the decision log for this piece.
- `README.md` — the repo README, part of the same launch set. Numbers must agree across the post, the README and the run report.
- `companion-v4-preslim.html` — the companion page in its current, pre-slim form. Use it only as a factual cross-reference. Its wording is one generation behind the decisions below and it gets its own pass later.

## Settled decisions, not open for re-litigation

- The five principles are called **tenets**, not commitments.
- The central component is named the **factory gateway**.
- The phrase "front door" is retired. Do not reintroduce it.
- The POC is supporting evidence only: one section of the post, one short proof beat per tenet. The headline block and the summary carry no POC mention and no numbers.
- References are numbered in order of first appearance in the text, Wikipedia style, listed at the end.
- The author's style rules apply to every word, captions included.

## What to check

1. **Facts.** Every number in the post against `RUN-REPORT.md`: the QASPER scores, the cache figures, the budget figures, the call counts, the prices, the cost of the run. Flag any mismatch or any number you cannot find in the report.
2. **Citations.** Every bracketed reference against the evidence bank and refresh. Honour the recorded caveats: the Mandiant denial-of-wallet passage was captured through a search index; the KVGov paper is a single-author preprint with a simulated defence; CVE-2025-46570 is rated LOW and is cited for measurability; the EU AI Act logging duties are deferred to 2027 and 2028 and must read as direction, not law in force. Flag any claim stated more strongly than its source.
3. **Style.** A zero-hit pass against `writing-style-instructions.md`: em dashes, LLM diction, contrast framing, rule-of-three padding, comma-and clause joins, mid-phrase colon injection, puffy transitions, monotonous rhythm. List each hit with its line.
4. **Structure.** Against `plan-and-decisions.md`: broad intro, summary with the tenets and the flow diagram, five tenet breakdowns on the fixed anatomy (principle, why it matters, practice, proof beat, takeaway), the proof told once, limits and provider questions to close.
5. **Consistency.** Post against README against companion on names, numbers and the tenet wording.
