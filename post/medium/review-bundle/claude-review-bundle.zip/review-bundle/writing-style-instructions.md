# Writing Style Instructions (consolidated 2026-10-22)

Apply to ALL generated content: resumes, SOQs, cover notes, articles, posts, and drafted emails. Goal: write like a person, with no AI fingerprints.

## The rules

1. **No em dashes.** Use commas, a colon at sentence level, or plain hyphens instead.
2. **No LLM diction.** Avoid delve, tapestry, landscape, and that family of inflated words. Plain words win.
3. **No contrast framing.** No "it's not X, it's Y" and no "not just X, but Y" parallel balance structures.
4. **No Rule-of-Three padding.** Do not default to triads with monotonous regularity. Vary list lengths; two items or four items are fine.
5. **Minimize ", and" clause joins.** Do not stack clauses with comma-and. Split into separate sentences, or use semicolons for list items.
6. **No mid-phrase colon injection.** A colon introduces a list or a sentence-level break; it does not glue extra clauses into the middle of a sentence.
7. **No puffy transitions.** Furthermore, moreover, in conclusion, and their cousins stay out. Plain connectives or none.
8. **Vary the rhythm.** Mix short and long sentences. Read it back as speech; if it sounds like a template, rewrite it.

## Before delivery

Run a check pass on every document for: em dashes, ", and" joins, mid-phrase colons, triads, balance structures, banned diction, and stiff transitions. Zero hits before the file goes out.

## Provenance

- Base rule set by Harish 2026-10-18 (no em dashes, no LLM diction, no contrast framing).
- Expanded 2026-10-20 from his SOQ review (Rule of Three, balance structures, ", and" and ":" joins, puffy transitions).
- Scope confirmed 2026-10-21: applies to resumes too (Hadrian CV ", and" catch).
- Consolidated into this single set 2026-10-22 at his request.
