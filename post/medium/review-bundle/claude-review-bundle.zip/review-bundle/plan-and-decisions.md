# Proposal: restructure the token factory post — Commitments, Principles, Practices

Prepared 2026-10-28 after reviewing: the Stage 1 run report and raw results, Claude's `post.md` draft (3,451 words), Claude's `index.html` companion, the Google Research post on agentic privacy and security, and the AWS Security Blog post "Four security principles for agentic AI systems".

## Diagnosis

The HTML is a dossier: framework reference, evidence bank, full POC record, appendices. That is the shape Stage 3 asked for, and it works as a companion document. It fails as the public narrative because it has no single argument running through it; facts are filed, not argued. Claude's `post.md` is closer: it argues tenet by tenet. Its weakness is layering — each section mixes principle, mechanism, citations and run output, so no audience gets a clean path: executives cannot stop early, practitioners must dig for the proof, and a hiring manager cannot tell in 30 seconds whether it is safe to forward.

The two reference posts solve this the same way. AWS states four numbered principles, gives each a short argument, and only then describes the building blocks that implement them. Google argues a lens, operationalises it, and keeps the deep material in a linked report; the blog is the argument, the report is the evidence. Both can be read by headings alone.

## The proposed shape

Three layers, in this order:

### Layer 1 — The glance (for executives; also the forward test)

- One-sentence thesis: an inference service is a multi-tenant system before it is a model endpoint, and the front door is the product.
- The five commitments as a numbered list, one line each (lowest cost; federate with the customer's IdP; isolate each tenant's data and cache; cap each tenant's spend; audit every call).
- A results strip, five numbers from the run: Tenant B's first call read 0 of 4,481 cached tokens with isolation on and 4,480 of 4,481 with it off; the spend cap stopped a 33-question batch at question 19 with 0.2% overshoot; 11 of 11 identity attacks rejected; 259 calls reconstructed end to end, $0.21 metered, matching the gateway's own spend log; the entire proof of concept cost $2.49 to run.
- Anyone who stops here has the whole argument. Anyone forwarding the post can see it is safe to forward.

### Layer 2 — The principles (the argument)

Five sections in the settled order (isolation, audit, federation, spend cap, cost). Each follows the AWS discipline:

- **Principle.** One quotable sentence.
- **Why it matters.** The problem stated plainly, in practitioner terms. At most two citations, only the strongest from the evidence bank. The problems are named as engineering problems the industry shares; no provider is named or graded.
- **The practice.** The mechanism, in two or three sentences, stated as design (what the gateway does), not as run narration.

Diagrams: D1 (the system) in the isolation or opening part, D2 (the resolved principal) in the federation or audit section.

### Layer 3 — The proof (the POC, told once)

One section: "A small instance, run once." The run narrated in order, briefly:

- Setup in four lines (one 4090, one gateway, two tenants, one agent, QASPER workload, past tense, infrastructure destroyed).
- The evidence table: the D2 contrast as the centrepiece (first-call cached tokens, salting on vs off), D1's stop at question 19, D3's 429 on the agent's seventh rapid call while the user's call succeeded, D4's totals and the cross-check against the spend log.
- The two tenant runs scoring the same work through two identity paths (F1 0.456 and 0.457) as the federation proof.
- The scars, kept in: token exchange was not advertised by the IdP, so the delegation used the shim-minted fallback; Tenant A's own budget cap fired during the D2 repeats and the passes were rerun. Practitioners trust runs that show their failures.
- D3 (one delegated call) diagram here.

### Close

- Limits in short form (one model, logical tenancy, the salt is not an isolation boundary, no sandbox layer).
- The questions to ask any inference provider: the tenets restated as questions a buyer can put in a security review. Short list, five items.
- Link to the companion HTML and the repository for the full framework, evidence bank and run report (the Google blog-to-report pattern).

## What moves out of the post (into the HTML, which keeps them)

- All citations beyond the strongest one or two per principle, including the full evidence cards and the "not verified, do not cite" appendix.
- The framework reference subsections (four paths in full, gateway comparison, reviewer security checklist).
- Verbatim demo outputs beyond the D2 contrast and the budget rejection line.
- QASPER methodology beyond one line and a link.

## Audience check

- **Executives:** Layer 1 plus headings. The argument survives a headings-only skim.
- **Practitioners:** Layer 3 plus the HTML. The unspoken problems (shared-cache timing channel, no hard per-key spend caps at providers, agents without their own identity) are stated as shared engineering problems, with measured evidence attached.
- **Hiring managers:** Layer 1 makes it forwardable; Layer 3 gives their teams something concrete to discuss; the repo and HTML hold the receipts.

## Targets and decisions

- Length: about 2,200 to 2,600 words (from 3,451), roughly a 10-minute read.
- Method: restructure `post.md`, do not redraft. Its per-tenet material is sound; the work is re-layering (pull run narration out of the principle sections into Layer 3, add Layer 1, tighten citations) plus a fresh pass under the author's style rules.
- The HTML needs only light edits: a role line at the top ("the detailed companion: framework, evidence and the full run record") and cross-links. It is not the post and should stop trying to be.
- Decisions for the author: (1) approve the three-layer restructure; (2) the provider-questions checklist in the close, short form in the post and full form in the HTML; (3) title shape: thesis-statement titles, e.g. "The Front Door of a Token Factory: Five Commitments for Shared Inference".

## Revision note, 2026-10-28 (from his HTML feedback round)
- Tenet 4 is reframed: "Cap each tenant's spend" becomes "Meter and manage spend." Metering is per principal (tenant, user, agent), budgets cap each level, and the gateway reports breakdowns back to the tenant (by agent, user, model, day), modelled on a context-usage report. Layer 2's spend section and Layer 1's commitment list inherit the new wording.
- The companion HTML (index-v4.html) now matches the article's reference style: no evidence layer; sources are 22 numbered references.

## Medium post plan, 2026-10-29 (his structure spec, modelled on "Anatomy of an Enterprise Agent — Part 2")
His spec: broad intro + summary with the importance of each tenet first, then each tenet semi-detailed. Borrowed from the reference: the overview list acts as the table of contents; each catalogue item follows one anatomy (bolded definition, visual or number, short explanation, one concrete example, closing takeaway); synthesis and a one-line key takeaway before the close; references as a list at the end. Not borrowed: 21 headings and 15 diagrams, a full recap section, the next-part teaser close.
- Part 1, broad intro (~400 words): post 1 linked in the first paragraph; the problem (sharing is the cost advantage and the risk); the thesis; one short definition block (what the front door is).
- Part 2, the summary (~300 words): the five tenets numbered, one importance line each; then the receipts strip, five headline numbers, one per tenet.
- Part 3, five tenet sections (~325 words each), fixed anatomy: bolded principle; why it matters with the strongest references [n]; the practice as design; one proof beat from the run; one takeaway line. Order: cost, federation, isolation, spend, audit (same order as the summary).
- Part 4, the proof told once (~350 words): the test bed in brief (three machines, one model, QASPER 33 questions, both tenants scored, the agent brief and throttle), diagram-led, plus the two scars in two sentences.
- Part 5, close (~200 words): key takeaway in one line; limits in a few lines; the five tenets restated as questions to ask any inference provider; links to repo and companion.
- References: numbered, only the sources the post actually cites (~12-14); the full 22 stay in the companion. Total target 2,600-3,000 words; three figures (system, D2 contrast, test bed).

## Plan revision, 2026-10-29 (his corrections)
- Part 2 carries NO numbers and no receipts strip. In their place, a data-flow diagram: how a call flows through the factory, the gateway's five steps in order, and the components the gateway interacts with (tenant IdP, tenant registry, ledger + audit store, tenant reports read back). Draftn drawn at diag-flow.html.
- Part 4 drafted in full at post-part4-draft.md (~470 words): test bed, workload, three paths, cache test, audit, scars, cost. Numbers live only in Part 4, woven into sentences.

Draft built 2026-10-29: post-draft.html in this folder (source post-body.html). Full post per the plan: intro, five commitments summary with the data-flow diagram, five breakdowns (isolation uses the approved why/impact passage; bars figure inside), the proof told once with the component diagram, limits plus provider questions close, 22 numbered references all cited in text. ~3,200 words including references. Repository and companion links are the planned launch URLs.
Style check pass run 2026-10-29 against writing-style-instructions.md: 28 prose fixes + 3 caption fixes (comma-and clause joins split, colon-glued clauses split, 5 contrast/balance structures rewritten, intro triad varied). Remaining comma-and and colon hits are all inside lists, which the rules allow. Rebuilt post-draft.html is the checked version.
Title settled 2026-10-29: Package B, "A Framework for Running a Shared Inference Service" / "Five tenets decide whether tenants can trust it. Here is the set, with the reasoning behind each." Word settled back to TENETS (his original 2026-10-27 term); "commitments" had drifted in from Claude Stage 2/3 drafts. "Front door" swept from headline and body as corny. Applied to post-body.html and post-draft.html; companion still carries the old wording until its slimming turn.
Component named 2026-10-29: the FACTORY GATEWAY (his pick over "factory router"; router names only one of its six jobs). Definition block introduces it, closing takeaway reads "Its gateway is the product," flow diagram header updated. Applied to the post draft.
Repo README companion file created 2026-10-29 at workspace/token-factory-poc-review/README.md (for argus-token-factory-gateway): tenets, factory gateway, build, run results, layout, reproduce, limits, credits. Style-checked. Article link is a launch-time fill.
